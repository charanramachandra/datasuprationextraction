document.getElementById('download-excel').addEventListener('click', function() {
    window.location.href = '/download_excel';
});

